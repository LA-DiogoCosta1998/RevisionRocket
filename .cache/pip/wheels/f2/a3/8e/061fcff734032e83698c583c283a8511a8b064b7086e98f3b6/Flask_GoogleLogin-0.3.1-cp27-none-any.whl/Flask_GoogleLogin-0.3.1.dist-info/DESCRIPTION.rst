Flask-GoogleLogin
-----------------
Flask-GoogleLogin extends Flask-Login to use Google's OAuth2 authorization

Links
`````
* `documentation <http://packages.python.org/Flask-GoogleLogin>`_
* `development version <https://github.com/marksteve/flask-googlelogin>`_


