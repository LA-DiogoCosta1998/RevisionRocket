A drop-in replacement for urlparse with enhancements.Provides mutable ParseResult fields and error handling for invaliddomains passed to urljoin.


